package com.wellsfargo.agiledashboard.controller;

import java.text.ParseException;
//import java.util.HashMap;
import java.util.List;
import java.util.Map;
//import java.util.stream.Collector;
import javax.servlet.http.HttpSession;
import org.codehaus.jettison.json.JSONException;
//import javax.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import com.mashape.unirest.http.exceptions.UnirestException;
import com.wellsfargo.agiledashboard.entity.IssueMaster;
import com.wellsfargo.agiledashboard.entity.SubTaskMaster;
import com.wellsfargo.agiledashboard.service.IssueService;
import com.wellsfargo.agiledashboard.service.SprintService;

@Controller
@RequestMapping("/issue")
public class IssueController {

	@Autowired
	IssueService issueService;
	@Autowired
	SprintService sprintService;
	HttpSession session;
	String sprintName;

	@SuppressWarnings("unchecked")
	@RequestMapping("/home")
	public String home(Model model) throws UnirestException, JSONException, ParseException {

		Map<String, String> datesMap;
		List<IssueMaster> issues;
		ServletRequestAttributes attr = (ServletRequestAttributes) RequestContextHolder.currentRequestAttributes();
		session = attr.getRequest().getSession();
		// List<IssueMaster> issues
		// =(List<IssueMaster>)session.getAttribute("issuecatalog");
		if (session.getAttribute("sprintMeta") == null || session.getAttribute("issueCatalog") == null) {
			datesMap = sprintService.getSprintDates();
			sprintName=datesMap.get("name");
			datesMap.remove("name");
			session.setAttribute("sprintMeta", datesMap);
			// fetching Issue list
			issues = issueService.getAllIssues();
			// keeping in session to reduce database or api call load
			session.setAttribute("issueCatalog", issues);
		} else {
			datesMap = (Map<String, String>) session.getAttribute("sprintMeta");
			issues = (List<IssueMaster>) session.getAttribute("issueCatalog");
		}
		model.addAttribute("name",sprintName);
		model.addAttribute("sprintMeta", datesMap);
		model.addAttribute("IssueList", issues);
		model.addAttribute("type", "Stories");
		return "show-all-item-issues";
	}

	@RequestMapping("/subtasks")
	public String subtasks(Model model) throws UnirestException, JSONException {

		ServletRequestAttributes attr = (ServletRequestAttributes) RequestContextHolder.currentRequestAttributes();
		session = attr.getRequest().getSession();
		// fetching Issue list
		List<SubTaskMaster> issues;
		// List<IssueMaster> issues
		// =(List<IssueMaster>)session.getAttribute("issuecatalog");
		if (session.getAttribute("Subtasks") == null) {
			// fetching subtasks list
			issues = issueService.getAllSubTasks();
			// keeping in session to reduce database or api call load
			session.setAttribute("Subtasks", issues);
		} else {
			issues = (List<SubTaskMaster>) session.getAttribute("Subtasks");
		}
		model.addAttribute("name",sprintName);
		model.addAttribute("IssueList", issues);
		model.addAttribute("type", "Sub Tasks");
		return "show-all-item-issues";
	}

	@SuppressWarnings({ "unchecked" })
	@RequestMapping("/sort/{type}/{by}")
	public String sortIssues(Model model, @PathVariable String type,@PathVariable String by) throws UnirestException, JSONException {
		List<IssueMaster> issues;
		if (type.equals("Issues")) {
			issues = (List<IssueMaster>) session.getAttribute("issueCatalog");
			session.setAttribute("issueCatalog", issues);
			model.addAttribute("type", "Stories");
		} else {
			issues = (List<IssueMaster>) session.getAttribute("Subtasks");
			session.setAttribute("Subtasks", issues);
			model.addAttribute("type", "Sub Tasks");
		}
		if (issues != null)
			issues = by.equals("status")?issueService.getAllSortedIssuesByStatus(issues):issueService.getAllSortedIssuesByAssignee(issues);
		model.addAttribute("IssueList", issues);
		return "show-all-item-issues";
	}

}
