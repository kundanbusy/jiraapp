package com.wellsfargo.agiledashboard.config;

import java.util.*;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import java.io.*;

@Component
public class LoadConfig {

	
	private Properties prop= new Properties();
	private String path, fullQPath;
	private InputStream is;

	public LoadConfig() {
		try {
			path = "./src/main/resources/";
			fullQPath = path  + "application.properties";
			is = new FileInputStream(fullQPath);
			prop.load(is);
		} catch (IOException e) {
			System.out.println(e.toString());
		} finally {
			try {
				is.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}

	public String readProperty(String key) {
		return ((prop.containsKey(key)) ? prop.getProperty(key) : "NoKeyFound");
	}
	
	public Map<String,String> readAllProperties()
	{
		Map<String,String> map=new HashMap<String, String>();
		Set<Object> keySet=prop.keySet();
		
		for(Object key : keySet)
		{
			map.put(key.toString(), prop.getProperty(key.toString()));
		}
		return map;
	}
}
