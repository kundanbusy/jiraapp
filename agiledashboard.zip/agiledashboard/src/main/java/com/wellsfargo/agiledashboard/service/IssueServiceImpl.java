package com.wellsfargo.agiledashboard.service;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.codehaus.jettison.json.JSONArray;
import org.codehaus.jettison.json.JSONException;
import org.codehaus.jettison.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mashape.unirest.http.HttpResponse;
import com.mashape.unirest.http.JsonNode;
import com.mashape.unirest.http.Unirest;
import com.mashape.unirest.http.exceptions.UnirestException;
import com.wellsfargo.agiledashboard.config.LoadConfig;
import com.wellsfargo.agiledashboard.entity.IssueMaster;
import com.wellsfargo.agiledashboard.entity.SubTaskMaster;
import com.wellsfargo.agiledashboard.misc.AssigneeCompare;
import com.wellsfargo.agiledashboard.misc.StatusCompare;

@Service
public class IssueServiceImpl implements IssueService {
	
	@Autowired
	LoadConfig properties;

	@Override
	public List<IssueMaster> getAllIssues() throws UnirestException, JSONException {
		String issueType;
		JSONArray arr = null;
		List<IssueMaster> issueList = new ArrayList<IssueMaster>();
		Map<String, Object> queryParam = new HashMap<>();
		queryParam.put("fields", "issuetype,summary,status,assignee");
		queryParam.put("maxResults", "1000");
		HttpResponse<JsonNode> jsonResponse = null;
		jsonResponse = Unirest.get("http://"+properties.readProperty("jira.host")+"/rest/agile/1.0/sprint/"+properties.readProperty("jira.current.sprint")+"/issue")
				.header("Authorization", "Basic "+properties.readProperty("jira.token"))
				.queryString(queryParam).asJson();
		JSONObject json = new JSONObject(jsonResponse.getBody().toString());
		arr = json.getJSONArray("issues");
		for (int i = 0; i < arr.length(); i++) {
			/*
			 * components=arr.getJSONObject(i).getJSONObject("fields").getJSONArray(
			 * "components"); if(components.isNull(0)) continue; else
			 * component=components.getJSONObject(0).getString("name");
			 */
			IssueMaster issue = new IssueMaster();
			issueType = arr.getJSONObject(i).getJSONObject("fields").getJSONObject("issuetype").getString("name");
			if (issueType.equals("Sub-task"))// ||!(component.contains("CTX Application")))
				continue;
			issue.setKey(arr.getJSONObject(i).getString("key"));
			issue.setSummary(arr.getJSONObject(i).getJSONObject("fields").getString("summary"));
			issue.setStatus(arr.getJSONObject(i).getJSONObject("fields").getJSONObject("status").getString("name"));
			if(arr.getJSONObject(i).getJSONObject("fields").getString("assignee").equals("null"))
				issue.setAssignee("Unassigned");
			else
				issue.setAssignee(arr.getJSONObject(i).getJSONObject("fields").getJSONObject("assignee").getString("displayName"));
			issueList.add(issue);

		}
		// System.out.println("Total Issue Count = "+cnt);

		return issueList;
	}

	@Override
	public List<SubTaskMaster> getAllSubTasks() throws UnirestException, JSONException {
		String issueType;
		JSONArray arr = null;
		List<SubTaskMaster> subTaskList = new ArrayList<SubTaskMaster>();
		Map<String, Object> queryParam = new HashMap<>();
		queryParam.put("fields", "issuetype,summary,status,assignee");
		queryParam.put("maxResults", "1000");
		HttpResponse<JsonNode> jsonResponse = null;
		jsonResponse = Unirest.get("http://"+properties.readProperty("jira.host")+"/rest/agile/1.0/sprint/"+properties.readProperty("jira.current.sprint")+"/issue")
				.header("Authorization", "Basic "+properties.readProperty("jira.token"))
				.queryString(queryParam).asJson();
		JSONObject json = new JSONObject(jsonResponse.getBody().toString());
		arr = json.getJSONArray("issues");
		for (int i = 0; i < arr.length(); i++) {
			/*
			 * components=arr.getJSONObject(i).getJSONObject("fields").getJSONArray(
			 * "components"); if(components.isNull(0)) continue; else
			 * component=components.getJSONObject(0).getString("name");
			 */
			SubTaskMaster subTask = new SubTaskMaster();
			issueType = arr.getJSONObject(i).getJSONObject("fields").getJSONObject("issuetype").getString("name");
			if (!(issueType.equals("Sub-task")))// ||!(component.contains("CTX Application")))
				continue;
			subTask.setKey(arr.getJSONObject(i).getString("key"));
			subTask.setSummary(arr.getJSONObject(i).getJSONObject("fields").getString("summary"));
			subTask.setStatus(arr.getJSONObject(i).getJSONObject("fields").getJSONObject("status").getString("name"));
			if(arr.getJSONObject(i).getJSONObject("fields").getString("assignee").equals("null"))
				subTask.setAssignee("Unassigned");
			else
				subTask.setAssignee(arr.getJSONObject(i).getJSONObject("fields").getJSONObject("assignee").getString("displayName"));
			subTaskList.add(subTask);

		}
		// System.out.println("Total Issue Count = "+cnt);

		return subTaskList;
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<IssueMaster> getAllSortedIssuesByStatus(List<IssueMaster> origIssueList) throws UnirestException, JSONException {
		// TODO Auto-generated method stub		
		Collections.sort(origIssueList,new StatusCompare());
		return origIssueList;
	}
	
	@SuppressWarnings("unchecked")
	@Override
	public List<IssueMaster> getAllSortedIssuesByAssignee(List<IssueMaster> origIssueList) throws UnirestException, JSONException {
		// TODO Auto-generated method stub		
		Collections.sort(origIssueList,new AssigneeCompare());
		return origIssueList;
	}

}
