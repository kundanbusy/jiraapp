package com.wellsfargo.agiledashboard.service;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;

import org.codehaus.jettison.json.JSONException;
import org.codehaus.jettison.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mashape.unirest.http.HttpResponse;
import com.mashape.unirest.http.JsonNode;
import com.mashape.unirest.http.Unirest;
import com.mashape.unirest.http.exceptions.UnirestException;
import com.wellsfargo.agiledashboard.config.LoadConfig;

@Service
public class SprintServiceImpl implements SprintService{
	
	@Autowired
	LoadConfig properties;

	@Override
	public Map<String, String> getSprintDates() throws UnirestException, JSONException, ParseException {
		// TODO Auto-generated method stub
		Calendar cal1 = Calendar.getInstance();
	    Calendar cal2 = Calendar.getInstance();
	    int numberOfDays = 0;
		Map<String,String> datesMap = new LinkedHashMap<>();
		HttpResponse<JsonNode> jsonResponse = null;
		jsonResponse = Unirest.get("http://"+properties.readProperty("jira.host")+"/rest/agile/1.0/sprint/"+properties.readProperty("jira.current.sprint"))
				.header("Authorization", "Basic "+properties.readProperty("jira.token"))
				.asJson();
		JSONObject json = new JSONObject(jsonResponse.getBody().toString());
		datesMap.put("name", json.getString("name"));
		//datesMap.put("SprintName",json.getString("name"));
		if(json.has("startDate"))
		{
			datesMap.put("Sprint Start",json.getString("startDate").substring(0, json.getString("startDate").indexOf("T")));
			datesMap.put("Sprint End",json.getString("endDate").substring(0, json.getString("endDate").indexOf("T")));
		}
		else
		{
			datesMap.put("Sprint Start","N/A in Jira");
			datesMap.put("Sprint End","N/A in Jira");
			datesMap.put("Days Remaining", "N/A");
			return datesMap;		
		}
		DateFormat df = new SimpleDateFormat("yyyy-MM-dd");
	    Date date1 = df.parse(df.format(new Date()));
	    Date date2 = df.parse(json.getString("endDate").substring(0, json.getString("endDate").indexOf("T")));
	    cal1.setTime(date1);
	    cal2.setTime(date2);
	    while (cal1.before(cal2)) {
	        if ((Calendar.SATURDAY != cal1.get(Calendar.DAY_OF_WEEK))
	           &&(Calendar.SUNDAY != cal1.get(Calendar.DAY_OF_WEEK))) {
	            numberOfDays++;
	        }
	        cal1.add(Calendar.DATE,1);
	    }
	    datesMap.put("Days Remaining", Integer.toString(numberOfDays));
		return datesMap;
	}

}
