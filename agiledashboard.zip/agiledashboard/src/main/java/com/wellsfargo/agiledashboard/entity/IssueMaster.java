package com.wellsfargo.agiledashboard.entity;

public class IssueMaster extends BaseEntity{

}
