package com.wellsfargo.agiledashboard.entity;

import com.atlassian.jira.rest.client.domain.Subtask;

public class SubTaskMaster extends BaseEntity{


}
