package com.wellsfargo.agiledashboard.service;

import java.text.ParseException;
import java.util.Map;

import org.codehaus.jettison.json.JSONException;

import com.mashape.unirest.http.exceptions.UnirestException;

public interface SprintService {
	public Map<String,String> getSprintDates() throws UnirestException, JSONException, ParseException;

}
