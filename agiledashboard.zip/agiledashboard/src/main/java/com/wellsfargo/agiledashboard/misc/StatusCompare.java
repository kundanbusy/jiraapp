package com.wellsfargo.agiledashboard.misc;

import java.util.Comparator;

import com.wellsfargo.agiledashboard.entity.BaseEntity;
import com.wellsfargo.agiledashboard.entity.IssueMaster;

public class StatusCompare implements Comparator<BaseEntity>{
	
	@Override
	public int compare(BaseEntity o1,BaseEntity o2) {
		// TODO Auto-generated method stub
		return((BaseEntity)o1).getStatus().compareTo(((BaseEntity)o2).getStatus()) ;
	}


}
