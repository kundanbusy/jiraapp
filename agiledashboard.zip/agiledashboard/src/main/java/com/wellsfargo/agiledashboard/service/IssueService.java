package com.wellsfargo.agiledashboard.service;

import java.util.List;

import org.codehaus.jettison.json.JSONException;

import com.mashape.unirest.http.exceptions.UnirestException;
import com.wellsfargo.agiledashboard.entity.IssueMaster;
import com.wellsfargo.agiledashboard.entity.SubTaskMaster;

public interface IssueService {
	
	public List<IssueMaster> getAllIssues() throws UnirestException, JSONException;
	public List<SubTaskMaster> getAllSubTasks() throws UnirestException, JSONException;
	public List<IssueMaster> getAllSortedIssuesByStatus(List<IssueMaster> origIssueList) throws UnirestException, JSONException;
	public List<IssueMaster> getAllSortedIssuesByAssignee(List<IssueMaster> origIssueList) throws UnirestException, JSONException;
}
