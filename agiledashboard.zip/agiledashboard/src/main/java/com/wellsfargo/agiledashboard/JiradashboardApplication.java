package com.wellsfargo.agiledashboard;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JiradashboardApplication {

	public static void main(String[] args) {
		SpringApplication.run(JiradashboardApplication.class, args);
	}
}